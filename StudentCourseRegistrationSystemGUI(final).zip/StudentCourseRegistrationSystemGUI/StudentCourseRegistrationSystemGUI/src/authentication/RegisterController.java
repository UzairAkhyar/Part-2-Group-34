package authentication;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import databaseManager.LecturerDatabaseController;
import databaseManager.StudentDatabaseController;
import databaseManager.UserDatabaseController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import modelView.Lecturer;
import modelView.Student;
import modelView.User;
import util.Helper;

/**
 * Represents the controller for the registration functionality.
 * Implements the Initializable interface for initialization.
 */
public class RegisterController implements Initializable {

    @FXML
    private TextField fName_tf;

    @FXML
    private TextField gmail_tf;

    @FXML
    private TextField lName_tf;

    @FXML
    private PasswordField password_tf;

    @FXML
    private TextField userNameTF;

    @FXML
    private ComboBox<String> userType_tf;

    private Helper helper = new Helper();

    private UserDatabaseController userDbController = new UserDatabaseController(null);
    private StudentDatabaseController studentDbController = new StudentDatabaseController(null);
    private LecturerDatabaseController lecturerDbController = new LecturerDatabaseController(null);

    /**
     * Handles the action triggered when the "Login" button is clicked.
     *
     * @param event The action event that triggered the method.
     * @throws IOException if an I/O error occurs.
     */
    @FXML
    void goToLoginPageBTN(ActionEvent event) throws IOException {
        helper.changeScene(event, "/authentication/Login.fxml");
    }

    /**
     * Handles the action triggered when the "Register" button is clicked.
     *
     * @param event The action event that triggered the method.
     * @throws IOException if an I/O error occurs.
     */
    @FXML
    void registerBTN(ActionEvent event) throws IOException {
        String f_Name = fName_tf.getText();
        String l_Name = lName_tf.getText();
        String email = gmail_tf.getText();
        String userName = userNameTF.getText();
        String password = password_tf.getText();
        String userType = userType_tf.getValue();
        int student_id, user_id, lecturer_id;
        String currentDate = helper.getCurrentDate();

        if (f_Name.isEmpty() || l_Name.isEmpty() || email.isEmpty() || userName.isEmpty() || password.isEmpty() || userType == null) {
            helper.showAlert("Empty Field!", "Please fill-up all the fields!");
        } else {

            user_id = helper.generateRandomNumber(8);
            User user = new User(user_id, userName, password, userType, f_Name, l_Name, email);
            boolean registrationSuccess = userDbController.insertUser(user);

            if (registrationSuccess) {

                if (userType.equals("Student")) {

                    student_id = helper.generateRandomNumber(8);
                    Student student = new Student(student_id, user_id, currentDate);
                    boolean isStdInsert = studentDbController.insertStudent(student);

                    if (isStdInsert) {
                        System.out.println("Welcome Mr. Student!");
                        helper.changeScene(event, "/authentication/Login.fxml");
                    }

                } else if (userType.equals("Lecturer")) {

                    lecturer_id = helper.generateRandomNumber(8);
                    Lecturer lecturer = new Lecturer(lecturer_id, user_id, currentDate);
                    boolean isLecInsert = lecturerDbController.insertLecturer(lecturer);

                    if (isLecInsert) {
                        System.out.println("Welcome Mr. Lecturer!");
                        helper.changeScene(event, "/authentication/Login.fxml");
                    }

                } else {
                    helper.changeScene(event, "/authentication/Registration.fxml");
                }

            } else {
                helper.showAlert("Registration Field!", "Please try again.");
            }

        }

    }

    /**
     * Initializes the controller.
     * This method is automatically called after the FXML file has been loaded.
     *
     * @param arg0 The URL of the FXML file.
     * @param arg1 The resource bundle associated with the FXML file.
     */
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        userType_tf.getItems().addAll("Student", "Lecturer");
    }

}
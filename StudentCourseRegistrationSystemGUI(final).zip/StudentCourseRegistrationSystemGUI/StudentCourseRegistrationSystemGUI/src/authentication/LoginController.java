package authentication;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import modelView.User;
import databaseManager.LecturerDatabaseController;
import databaseManager.StudentDatabaseController;
import databaseManager.UserDatabaseController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import util.Helper;

/**
 * Represents the controller for the login functionality.
 * Implements the Initializable interface for initialization.
 */
public class LoginController implements Initializable {

    @FXML
    private TextField gmail_tf;

    @FXML
    private PasswordField password_tf;

    @FXML
    private ComboBox<String> userType_tf;
    
    private static int userId; 
    
    private Helper helper = new Helper();
    private UserDatabaseController user_DB_C = new UserDatabaseController(null);
    private StudentDatabaseController student_database = new StudentDatabaseController(null);
    private LecturerDatabaseController lecturerDatabase = new LecturerDatabaseController(null);

    /**
     * Handles the action triggered when the "Register" button is clicked.
     *
     * @param event The action event that triggered the method.
     * @throws IOException if an I/O error occurs.
     */
    @FXML
    void goToRegisterPageBTN(ActionEvent event) throws IOException {
        helper.changeScene(event, "/authentication/Registration.fxml");
    }

    /**
     * Handles the action triggered when the "Login" button is clicked.
     *
     * @param event The action event that triggered the method.
     * @throws IOException if an I/O error occurs.
     */
    @FXML
    void loginBTN(ActionEvent event) throws IOException {
        String email = gmail_tf.getText();
        String password = password_tf.getText();
        String userType = (String) userType_tf.getValue();
        int userID = user_DB_C.getUserIdByGmail(email);

        if (email.isEmpty() || password.isEmpty() || userType == null) {
            helper.showAlert("Empty Field!", "Please fill-up all the fields!");
        } else {

            User user = new User();
            user.setEmail(email);
            user.setPassword(password);
            user.setUserType(userType);
            user.setUserID(userID);

            if (!userType.equals("Admin") && userID == -1) {
                helper.showAlert("Authentication Error!", "Please provide correct email.");
                return;
            }

            System.out.println("User Id : " + userID);

            // Set user id as session id
            setUserId(userID);

            if (userType.equals("Student")) {

                if (student_database.checkUserID(user.getUserID())) {
                    System.out.println("Successfully login as [Student]");
                    helper.changeScene(event, "/student/Student.fxml");
                } else {
                    helper.showAlert("Authentication Error!", "Please provide correct input!");
                }

            } else if (userType.equals("Lecturer")) {

                if (lecturerDatabase.checkUserID(user.getUserID())) {
                    System.out.println("Successfully login as [Lecturer]");
                    helper.changeScene(event, "/lecturer/Lecturer.fxml");
                } else {
                    helper.showAlert("Authentication Error!", "Please provide correct input!");
                }

            } else if (userType.equals("Admin")) {
                if (email.equals("admin@gmail.com") && password.equals("admin")) {
                    System.out.println("Successfully login as [Admin]");
                    helper.changeScene(event, "/admin/Admin.fxml");
                } else {
                    helper.showAlert("Authentication Error!", "Please provide correct input!");
                }
            }
        }
    }

    /**
     * Initializes the controller.
     * This method is automatically called after the FXML file has been loaded.
     *
     * @param arg0 The URL of the FXML file.
     * @param arg1 The resource bundle associated with the FXML file.
     */
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        userType_tf.getItems().addAll("Lecturer", "Student", "Admin");
    }

    /**
     * Gets the user ID.
     *
     * @return The user ID.
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Sets the user ID.
     *
     * @param userId The user ID to set.
     */
    public void setUserId(int userId) {
        LoginController.userId = userId;
    }

}
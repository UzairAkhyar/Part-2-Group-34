module StudentCourseRegistrationSystemGUI {
    requires javafx.controls;
    requires javafx.fxml;

    opens admin;
    opens admin.student;
    opens admin.lecturer;
    opens admin.course;
    opens admin.assignCourse;
    opens authentication;
    
    opens student;
    opens student.courseRegistration;
    
    opens lecturer;
    opens lecturer.students;

    opens application to javafx.graphics, javafx.fxml;
    opens modelView; 
}

package admin.student;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import databaseManager.StudentDatabaseController;
import databaseManager.UserDatabaseController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modelView.Student;
import modelView.User;
import util.Helper;

/**
 * Represents the controller for managing students in the admin interface.
 * Implements the Initializable interface for initialization.
 */
public class AdminStudentManageController implements Initializable {

    @FXML
    private TableColumn<Student, String> registrationDate;

    @FXML
    private TableColumn<Student, Integer> studentId;

    @FXML
    private TableView<Student> student_table;

    @FXML
    private TableColumn<Student, Integer> userID;

    @FXML
    private TextField email_tf;

    @FXML
    private TextField firstName_tf;

    @FXML
    private TextField lastName_tf;

    @FXML
    private PasswordField password_tf;
    
    @FXML
    private TextField userId_tf;

    @FXML
    private TextField userName_tf;
    
    private UserDatabaseController userDbController = new UserDatabaseController(null);
    private StudentDatabaseController studentDbController = new StudentDatabaseController(null);
    private Helper helper = new Helper();

    /**
     * Handles the action triggered when the "Add" button is clicked.
     *
     * @param event The action event that triggered the method.
     * @throws IOException if an I/O error occurs.
     */
    @FXML
    void addBTN(ActionEvent event) throws IOException {
        String user_type = "Student";
        int student_id, userID;
        String currentDate = helper.getCurrentDate();

        // Get input values from the text fields
        String firstName = firstName_tf.getText();
        String lastName = lastName_tf.getText();
        String email = email_tf.getText();
        String userName = userName_tf.getText();
        String password = password_tf.getText();
        userID = Integer.parseInt(userId_tf.getText());

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || userName.isEmpty() || password.isEmpty()) {
            helper.showAlert("Empty Fields", "Please fill in all the required fields.");
            return;
        }

        User user = new User(userID, userName,password, user_type, firstName, lastName, email);
        boolean registrationSuccess = userDbController.insertUser(user);
    	
        if (registrationSuccess) {
            student_id = helper.generateRandomNumber(8);
            Student student = new Student(student_id, userID, currentDate);
            boolean isStdInsert = studentDbController.insertStudent(student);
    			
            if (isStdInsert) {
                helper.showAlert("Insertion Successful.", "Student data inserted successfully!");
                loadTableData();
                clearBTN(event);
            }
        } else {
            helper.showAlert("Insertion Failed!", "Please try again.");
        }
    }


    /**
     * Handles the action triggered when the "Clear" button is clicked.
     *
     * @param event The action event that triggered the method.
     */
    @FXML
    void clearBTN(ActionEvent event) {
        firstName_tf.clear();
        lastName_tf.clear();
        email_tf.clear();
        userName_tf.clear();
        password_tf.clear();
        userId_tf.setText(helper.generateRandomNumber(8) + "");
    }
    
    
    /**
     * Loads the data into the table view.
     */
    @FXML
    private void loadTableData() {
        List<Student> allStudents = studentDbController.getAllStudent();

        if (allStudents != null) {
            ObservableList<Student> studentData = FXCollections.observableArrayList(allStudents);

            studentId.setCellValueFactory(new PropertyValueFactory<>("studentID"));
            registrationDate.setCellValueFactory(new PropertyValueFactory<>("registrationDate"));
            userID.setCellValueFactory(new PropertyValueFactory<>("userID"));

            student_table.setItems(studentData);
        }
    }


    /**
     * Initializes the controller.
     * This method is automatically called after the FXML file has been loaded.
     *
     * @param arg0 The URL of the FXML file.
     * @param arg1 The resource bundle associated with the FXML file.
     */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		loadTableData();
		
		userId_tf.setText(helper.generateRandomNumber(8)+"");
		
		student_table.setOnMouseClicked(event -> {
	        if (event.getClickCount() == 1) { 
	            handleRowSelection();
	        }
	    });
	}
	
	/**
     * Handles the row selection in the student_table.
     * Retrieves the selected student's details and populates the corresponding text fields.
     */
	private void handleRowSelection() {
	    Student selectedStudent = student_table.getSelectionModel().getSelectedItem();

	    if (selectedStudent!= null) {
	        int userID = selectedStudent.getUserID();
	        User user = userDbController.getUserByUserID(userID);
	        
	        email_tf.setText(user.getEmail());
	        firstName_tf.setText(user.getFirstName());
	        lastName_tf.setText(user.getLastName());
	        password_tf.setText(user.getPassword());
	        userId_tf.setText(""+user.getUserID());
	        userName_tf.setText(user.getUsername());      

	    }
	}

}
package admin;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import util.Helper;

/**
 * Represents the controller for the admin interface.
 * Implements the Initializable interface for initialization.
 */
public class AdminController implements Initializable {

    @FXML
    private StackPane admin_content_container_stack_pan;

    @FXML
    private ImageView admin_left_head_img;

    @FXML
    private AnchorPane admin_left_menu_container;

    @FXML
    private ImageView admin_left_menu_icon_admin;

    @FXML
    private ImageView admin_left_menu_icon_apointment;

    @FXML
    private ImageView admin_left_menu_icon_doctors;

    @FXML
    private ImageView admin_left_menu_icon_logout;

    @FXML
    private ImageView admin_left_menu_icon_patients;

    @FXML
    private AnchorPane admin_left_menu_items_container;

    @FXML
    private AnchorPane admin_left_menu_items_container1;

    @FXML
    private AnchorPane admin_left_menu_items_container2;

    @FXML
    private AnchorPane admin_left_menu_items_container3;

    @FXML
    private AnchorPane admin_left_menu_items_container31;

    @FXML
    private AnchorPane admin_main_container;

    @FXML
    private ImageView image;
    
    private Helper helper = new Helper();
    
    private ActionEvent event =  new ActionEvent();

    /**
     * Handles the action triggered when the "Add Course" button is clicked.
     *
     * @param event The action event.
     * @throws IOException If there is an error loading the corresponding FXML file.
     */
    @FXML
    void addCourseBtn(ActionEvent event) throws IOException {
        helper.loadContainer(admin_content_container_stack_pan, "/admin/course/AdminCourseManage.fxml");	   
    }

    /**
     * Handles the action triggered when the "Assign Course" button is clicked.
     *
     * @param event The action event.
     * @throws IOException If there is an error loading the corresponding FXML file.
     */
    @FXML
    void assignCourseBTN(ActionEvent event) throws IOException {
        helper.loadContainer(admin_content_container_stack_pan, "/admin/assignCourse/AdminAssignCourseManage.fxml");
    }

    /**
     * Handles the action triggered when the "Create Lecturer" button is clicked.
     *
     * @param event The action event.
     * @throws IOException If there is an error loading the corresponding FXML file.
     */
    @FXML
    void createLecturerBtn(ActionEvent event) throws IOException {
        helper.loadContainer(admin_content_container_stack_pan, "/admin/lecturer/AdminLecturerManage.fxml");     
    }

    /**
     * Handles the action triggered when the "Create Student" button is clicked.
     *
     * @param event The action event.
     * @throws IOException If there is an error loading the corresponding FXML file.
     */
    @FXML
    void createStudentBTN(ActionEvent event) throws IOException {
        helper.loadContainer(admin_content_container_stack_pan, "/admin/student/AdminStudentManage.fxml");
    }

    /**
     * Handles the action triggered when the "Log Out" button is clicked.
     *
     * @param event The action event.
     * @throws IOException If there is an error loading the corresponding FXML file.
     */
    @FXML
    void logOut_action_btn(ActionEvent event) throws IOException {
        helper.logOut_action_btn(event, admin_content_container_stack_pan, "/authentication/Login.fxml");
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

        try {
            createStudentBTN(event);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        //admin-logo.png
        Image admin_logo_icon = new Image(getClass().getResourceAsStream("/images/admin-logo.png"));
        admin_left_head_img.setImage(admin_logo_icon);
        
    }

}
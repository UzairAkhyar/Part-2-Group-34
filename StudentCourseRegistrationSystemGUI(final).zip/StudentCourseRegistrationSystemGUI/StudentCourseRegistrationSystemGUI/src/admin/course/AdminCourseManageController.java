package admin.course;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import databaseManager.CourseDatabaseController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modelView.Course;
import util.Helper;

/**
 * Represents the controller for managing courses in the admin interface.
 * Implements the Initializable interface for initialization.
 */
public class AdminCourseManageController implements Initializable {

    @FXML
    private TableColumn<Course, String> courseCode_col;

    @FXML
    private TextField courseCode_tf;

    @FXML
    private TableColumn<Course, String> courseDesc_col;

    @FXML
    private TextArea courseDescription_tf;

    @FXML
    private TableColumn<Course, Integer> courseID_col;

    @FXML
    private TextField courseID_tf;

    @FXML
    private TableColumn<Course, String> courseName_col;

    @FXML
    private TextField courseName_tf;

    @FXML
    private TableView<Course> course_table;
    
    private CourseDatabaseController courseDbController = new CourseDatabaseController(null);
    private Helper helper = new Helper();

    /**
     * Handles the action triggered when the "Add" button is clicked.
     *
     * @param event The action event that triggered the method.
     */
    @FXML
    void addBTN(ActionEvent event) {
        int courseID;
        String courseCode, courseName, courseDescription;

        try {
            courseID = Integer.parseInt(courseID_tf.getText());
            courseCode = courseCode_tf.getText();
            courseName = courseName_tf.getText();
            courseDescription = courseDescription_tf.getText();
        } catch (NumberFormatException e) {
            helper.showAlert("Invalid Input", "Please enter a valid course ID.");
            return;
        }

        if (courseCode.isEmpty() || courseName.isEmpty() || courseDescription.isEmpty()) {
            helper.showAlert("Empty Fields", "Please fill in all the required fields.");
            return;
        }

        Course newCourse = new Course(courseID, courseName, courseCode, courseDescription);
        boolean isInserted = courseDbController.insertCourse(newCourse);

        if (isInserted) {
            helper.showAlert("Insertion Successful", "Course added successfully!");
            loadTableData();
            clearBTN(event);
        } else {
            helper.showAlert("Insertion Failed", "Course with the same ID already exists.");
        }
    }

    /**
     * Handles the action triggered when the "Clear" button is clicked.
     *
     * @param event The action event that triggered the method.
     */
    @FXML
    void clearBTN(ActionEvent event) {
        courseID_tf.clear();
        courseCode_tf.clear();
        courseName_tf.clear();
        courseDescription_tf.clear();
    }

    /**
     * Loads the data into the table view.
     */
    private void loadTableData() {
        List<Course> allCourses = courseDbController.getAllCourses();

        if (allCourses != null) {
            ObservableList<Course> courseData = FXCollections.observableArrayList(allCourses);

            courseID_col.setCellValueFactory(new PropertyValueFactory<>("courseID"));
            courseCode_col.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
            courseName_col.setCellValueFactory(new PropertyValueFactory<>("courseName"));
            courseDesc_col.setCellValueFactory(new PropertyValueFactory<>("description"));

            course_table.setItems(courseData);
        }
    }

    /**
     * Initializes the controller.
     * This method is automatically called after the FXML file has been loaded.
     *
     * @param arg0 The URL of the FXML file.
     * @param arg1 The resource bundle associated with the FXML file.
     */
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        loadTableData();
        
        courseID_tf.setText(helper.generateRandomNumber(8)+"");
    }
}
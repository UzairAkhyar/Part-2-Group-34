package admin.assignCourse;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import databaseManager.CourseAssignDatabaseController;
import databaseManager.CourseDatabaseController;
import databaseManager.LecturerDatabaseController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modelView.CourseAssignment;
import util.Helper;

/**
 * Represents the controller for managing course assignments in the admin interface.
 * Implements the Initializable interface for initialization.
 */
public class AdminAssignCourseManageController implements Initializable {

    @FXML
    private TableView<CourseAssignment> acourse_assign_table;

    @FXML
    private TableColumn<CourseAssignment, Integer> assignID_col;

    @FXML
    private TextField assignID_tf;

    @FXML
    private TableColumn<CourseAssignment, Integer> courseID_col;

    @FXML
    private ComboBox<String> courseID_tf;

    @FXML
    private TableColumn<CourseAssignment, Integer> lectureID_col;

    @FXML
    private ComboBox<String> lecturerID_tf;

    @FXML
    private TextField trimester_TF;

    @FXML
    private TableColumn<CourseAssignment, String> trimester_col;

    @FXML
    private TableColumn<CourseAssignment, Integer> year_col;

    @FXML
    private TextField year_tf;
    
    private CourseDatabaseController courseDbController = new CourseDatabaseController(null);
    private LecturerDatabaseController lecturerDbController = new LecturerDatabaseController(null);
    private CourseAssignDatabaseController courseAssignDbController = new CourseAssignDatabaseController(null);
    private Helper helper = new Helper();

    /**
     * Handles the action triggered when the "Add" button is clicked.
     *
     * @param event The action eventthat triggered the method.
     */
    @FXML
    void addBTN(ActionEvent event) {
        try {
            // Get the input values from the text fields and combo boxes
            int assignID = Integer.parseInt(assignID_tf.getText());
            int courseID = courseDbController.getCourseIdByCourseCode(courseID_tf.getValue());

            String rawLecturerID = lecturerID_tf.getValue();
            String numericLecturerID = rawLecturerID.replaceAll("[^0-9]", "");
            int lecturerID = Integer.parseInt(numericLecturerID);

            String trimester = trimester_TF.getText();
            int year = Integer.parseInt(year_tf.getText());

            System.out.println("Assign ID: " + assignID);
            System.out.println("Course ID: " + courseID);
            System.out.println("Lecturer ID: " + lecturerID);
            System.out.println("Trimester: " + trimester);
            System.out.println("Year: " + year);

            // Validate the input values
            if (assignID == 0 || courseID == 0 || trimester.isEmpty() || year == 0) {
                helper.showAlert("Empty Input", "Input fields cannot be empty or zero.");
                return;
            }
            
            // Create a new CourseAssignment object
            CourseAssignment courseAssign = new CourseAssignment(assignID, courseID, lecturerID, trimester, year);
            
            // Insert the course assignment into the database
            boolean isInsert = courseAssignDbController.insertCourseAssignment(courseAssign);
            
            // Show appropriate success or error message
            if (isInsert) {
                helper.showAlert("Success", "Course assignment added successfully.");
                clearBTN(event);
                loadTableData();
            } else {
                helper.showAlert("Error", "Failed to add course assignment.");
            }

        } catch (NumberFormatException e) {
            helper.showAlert("Invalid Input", "Please enter valid numeric values for ID and Year.");
        }
    }

    /**
     * Handles the action triggered when the "Clear" button is clicked.
     *
     * @param event The action event that triggered the method.
     */
    @FXML
    void clearBTN(ActionEvent event) {
        // Generate a random assignment ID
        assignID_tf.setText(helper.generateRandomNumber(8) + "");
        
        // Clear the selected values in the combo boxes and text fields
        courseID_tf.getSelectionModel().clearSelection();
        lecturerID_tf.getSelectionModel().clearSelection();
        trimester_TF.clear();
        year_tf.clear();
    }

    /**
     * Loads the data into the table view.
     */
    private void loadTableData() {
        // Retrieve all course assignments from the database
        List<CourseAssignment> allCourseAssignments = courseAssignDbController.getAllCourseAssignments();

        if (allCourseAssignments != null) {
            // Create an observable list to hold the course assignments
            ObservableList<CourseAssignment> assignmentData = FXCollections.observableArrayList(allCourseAssignments);

            // Bind the columns to the corresponding properties of the CourseAssignment object
            assignID_col.setCellValueFactory(new PropertyValueFactory<>("assignmentID"));
            courseID_col.setCellValueFactory(new PropertyValueFactory<>("courseID"));
            lectureID_col.setCellValueFactory(new PropertyValueFactory<>("lecturerID"));
            trimester_col.setCellValueFactory(new PropertyValueFactory<>("trimester"));
            year_col.setCellValueFactory(new PropertyValueFactory<>("year"));

            // Set the data in the table view
            acourse_assign_table.setItems(assignmentData);
        }
    }

    /**
     * Initializes the controller.
     * This method is automatically called after the FXML file has been loaded.
     *
     * @param arg0 The URL of the FXML file.
     * @param arg1 The resource bundle associated with the FXML file.
     */
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // Retrieve all course codes and add them to the course ID combo box
        List<String> allCorseCode = courseDbController.getAllCourseCodes();
        courseID_tf.getItems().addAll(allCorseCode);
        
        // Retrieve all lecturers and add them to the lecturer ID combo box
        List<String> allLecturersFormatted = lecturerDbController.getAllLecturersFormatted();
        lecturerID_tf.getItems().addAll(allLecturersFormatted);
        
        // Generate a random assignment ID
        assignID_tf.setText(helper.generateRandomNumber(8)+"");
        
        // Load the table data
        loadTableData();
    }
}
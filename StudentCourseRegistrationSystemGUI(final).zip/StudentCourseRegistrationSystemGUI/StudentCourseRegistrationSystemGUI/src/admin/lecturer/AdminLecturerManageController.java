package admin.lecturer;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import databaseManager.LecturerDatabaseController;
import databaseManager.UserDatabaseController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modelView.Lecturer;
import modelView.User;
import util.Helper;

/**
 * Represents the controller for managing lecturers in the admin interface.
 * Implements the Initializable interface for initialization.
 */
public class AdminLecturerManageController implements Initializable {

    @FXML
    private TableColumn<Lecturer, String> hireDate_col;

    @FXML
    private TableColumn<Lecturer, Integer> lecturerId_col;

    @FXML
    private TableView<Lecturer> lecturer_table;

    @FXML
    private TableColumn<Lecturer, Integer> userID_col;

    @FXML
    private TextField email_tf;

    @FXML
    private TextField fName_tf;
    
    @FXML
    private TextField lName_tf;
    
    @FXML
    private PasswordField password_tf;
    
    @FXML
    private TextField userId_tf;

    @FXML
    private TextField username_tf;
    
    private LecturerDatabaseController lecturerDbController = new LecturerDatabaseController(null);
    private UserDatabaseController userDbController = new UserDatabaseController(null);
    private Helper helper = new Helper();

    /**
     * Handles the action triggered when the "Add" button is clicked.
     *
     * @param event The action event that triggered the method.
     * @throws IOException if an I/O error occurs.
     */
    @FXML
    void addBTN(ActionEvent event) throws IOException {
        String user_type = "Lecturer";
        int lecturer_id, userID;
        String currentDate = helper.getCurrentDate();

        String firstName = fName_tf.getText();
        String lastName = lName_tf.getText();
        String email = email_tf.getText();
        String userName = username_tf.getText();
        String password = password_tf.getText();
        userID = Integer.parseInt(userId_tf.getText());

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || userName.isEmpty() || password.isEmpty()) {
            helper.showAlert("Empty Fields", "Please fill in all the required fields.");
            return;
        }

        User user = new User(userID, userName, password, user_type, firstName, lastName, email);
        boolean registrationSuccess = userDbController.insertUser(user);
    	
        if (registrationSuccess) {
            lecturer_id = helper.generateRandomNumber(8);
            Lecturer lecturer = new Lecturer(lecturer_id, userID, currentDate);
            boolean isLecturerInsert = lecturerDbController.insertLecturer(lecturer);
    
            if (isLecturerInsert) {
                helper.showAlert("Insertion Successful.", "Lecturer data inserted successfully!");
                loadTableData();
                clearBTN(event);
            }
        } else {
            helper.showAlert("Insertion Failed!", "Please try again.");
        }
    }

    /**
     * Handles the action triggered when the "Clear" button is clicked.
     *
     * @param event The action event that triggered the method.
     */
    @FXML
    void clearBTN(ActionEvent event) {
        fName_tf.clear();
        lName_tf.clear();
        email_tf.clear();
        username_tf.clear();
        password_tf.clear();
        userId_tf.setText(helper.generateRandomNumber(8) + "");
    }

    /**
     * Loads the data into the table view.
     */
    @FXML
    private void loadTableData() {
        List<Lecturer> lecturerList = lecturerDbController.getAllLecturers();

        if (lecturerList != null) {
            ObservableList<Lecturer> lecturerData = FXCollections.observableArrayList(lecturerList);

            lecturerId_col.setCellValueFactory(new PropertyValueFactory<>("lecturerID"));
            hireDate_col.setCellValueFactory(new PropertyValueFactory<>("hireDate"));
            userID_col.setCellValueFactory(new PropertyValueFactory<>("userID"));

            lecturer_table.setItems(lecturerData);
        }
    }

    /**
     * Initializes the controller.
     * This method is automatically called after the FXML file has been loaded.
     *
     * @param arg0 The URL of the FXML file.
     * @param arg1 The resource bundle associated with the FXML file.
     */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		loadTableData();
		userId_tf.setText(helper.generateRandomNumber(8)+"");
		
	    lecturer_table.setOnMouseClicked(event -> {
	        if (event.getClickCount() == 1) { 
	            handleRowSelection();
	        }
	    });
	}
	
	/**
     * Handles the row selection in thelecturer_table.
     * Retrieves the selected lecturer's details and populates the corresponding text fields.
     */
	private void handleRowSelection() {
	    Lecturer selectedLecturer = lecturer_table.getSelectionModel().getSelectedItem();

	    if (selectedLecturer != null) {
	        int userID = selectedLecturer.getUserID();

	        User user = userDbController.getUserByUserID(userID);
	        
	        email_tf.setText(user.getEmail());
	        fName_tf.setText(user.getFirstName());
	        lName_tf.setText(user.getLastName());
	        password_tf.setText(user.getPassword());
	        userId_tf.setText(""+user.getUserID());
	        username_tf.setText(user.getUsername());       
	    }
	}

}
package util;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * Utility class providing helper methods for common tasks.
 */
public class Helper {

    /**
     * Generates a random number with the specified number of digits.
     * @param digit The number of digits for the random number.
     * @return A random number with the specified number of digits.
     * @throws IllegalArgumentException if the number of digits is less than or equal to 0.
     */
    public int generateRandomNumber(int digit) {
        if (digit <= 0) {
            throw new IllegalArgumentException("number of digits must be greater than 0");
        }

        int min = (int) Math.pow(10, digit - 1);
        int max = (int) Math.pow(10, digit) - 1;

        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }
    
    /**
     * Retrieves the current date in the format "yyyy-MM-dd".
     * @return The current date as a string in "yyyy-MM-dd" format.
     */
    public String getCurrentDate() {
    	LocalDate currentDate = LocalDate.now();
        String formattedDate = currentDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        return formattedDate;
    }
       
	/**
	 * Loads an FXML container into a StackPane.
	 * @param container The StackPane where the FXML container will be loaded.
	 * @param url The URL of the FXML file to load.
	 * @throws IOException If an error occurs while loading the FXML file.
	 */
	public void loadContainer(StackPane container, String url) throws IOException {
		AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource(url));
		container.getChildren().removeAll();
		container.getChildren().setAll(root);
	}

	/**
	 * Displays an alert dialog with the specified title and message.
	 * @param title The title of the alert dialog.
	 * @param message The message to display in the alert dialog.
	 */
	public void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);

        Stage alertStage = (Stage) alert.getDialogPane().getScene().getWindow();
        alertStage.initModality(Modality.APPLICATION_MODAL);
        alertStage.initStyle(StageStyle.UNDECORATED);

        ButtonType okButton = new ButtonType("OK");
        alert.getButtonTypes().setAll(okButton);
        alert.showAndWait();      	
	}

	/**
	 * Changes the scene to the specified FXML file.
	 * @param event The ActionEvent that triggered the scene change.
	 * @param url The URL of the FXML file to load.
	 * @throws IOException If an error occurs while loading the FXML file.
	 */
	public void changeScene(ActionEvent event, String url) throws IOException {
		Stage currentStage = (Stage) ((Node) (event.getSource())).getScene().getWindow();
	    Parent root = FXMLLoader.load(getClass().getResource(url));
	    Scene scene = new Scene(root);
	    Stage newStage = new Stage();
	    newStage.setScene(scene);
	    currentStage.close();
	    newStage.show();		
	}
	
    /**
     * Logs out the user by changing the scene to the login page.
     * @param event The ActionEvent that triggered the logout action.
     * @param pane The StackPane containing the current scene.
     * @param url The URL of the login page FXML file.
     * @throws IOException If an error occurs while loading the login page.
     */
    public void logOut_action_btn(ActionEvent event, StackPane pane, String url) throws IOException {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Are you sure you want to logout?");
        alert.setContentText("Click 'Yes' to logout or 'No' to cancel.");

        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            System.out.println("Logout successful!");
            AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource(url));
            Scene scene = new Scene(root);
            Stage stage = (Stage) pane.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
            
        } else {
            System.out.println("Logout canceled.");
            
        }
    }  
}

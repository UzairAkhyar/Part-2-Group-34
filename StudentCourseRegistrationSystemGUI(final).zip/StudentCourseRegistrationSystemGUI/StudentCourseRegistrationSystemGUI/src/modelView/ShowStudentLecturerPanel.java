package modelView;

import java.io.Serializable;

public class ShowStudentLecturerPanel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int Student_ID;
	private String Student_gmail;
	private String Student_full_name;
	private String Course_reg_date;
	
	public ShowStudentLecturerPanel() {
		
	}

	public ShowStudentLecturerPanel(int student_ID, String student_gmail, String student_full_name,
			String course_reg_date) {
		super();
		Student_ID = student_ID;
		Student_gmail = student_gmail;
		Student_full_name = student_full_name;
		Course_reg_date = course_reg_date;
	}

	@Override
	public String toString() {
		return "ShowStudentLecturerPanel [Student_ID=" + Student_ID + ", Student_gmail=" + Student_gmail
				+ ", Student_full_name=" + Student_full_name + ", Course_reg_date=" + Course_reg_date + "]";
	}

	public int getStudent_ID() {
		return Student_ID;
	}

	public void setStudent_ID(int student_ID) {
		Student_ID = student_ID;
	}

	public String getStudent_gmail() {
		return Student_gmail;
	}

	public void setStudent_gmail(String student_gmail) {
		Student_gmail = student_gmail;
	}

	public String getStudent_full_name() {
		return Student_full_name;
	}

	public void setStudent_full_name(String student_full_name) {
		Student_full_name = student_full_name;
	}

	public String getCourse_reg_date() {
		return Course_reg_date;
	}

	public void setCourse_reg_date(String course_reg_date) {
		Course_reg_date = course_reg_date;
	}
	
}

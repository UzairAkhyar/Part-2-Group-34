package modelView;


import java.io.Serializable;
import java.time.LocalDate;

public class StudentCourseRegistration implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int registrationID;
    private int studentID;
    private int courseID;
    private String trimester;
    private int year;
    private LocalDate registrationDate;
    
	public StudentCourseRegistration(int registrationID, int studentID, int courseID, String trimester, int year,
			LocalDate registrationDate) {
		super();
		this.registrationID = registrationID;
		this.studentID = studentID;
		this.courseID = courseID;
		this.trimester = trimester;
		this.year = year;
		this.registrationDate = registrationDate;
	}
	
	@Override
	public String toString() {
		return "StudentCourseRegistration [registrationID=" + registrationID + ", studentID=" + studentID
				+ ", courseID=" + courseID + ", trimester=" + trimester + ", year=" + year + ", registrationDate="
				+ registrationDate + "]";
	}

	public int getRegistrationID() {
		return registrationID;
	}

	public void setRegistrationID(int registrationID) {
		this.registrationID = registrationID;
	}

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

	public String getTrimester() {
		return trimester;
	}

	public void setTrimester(String trimester) {
		this.trimester = trimester;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}
}

package modelView;

import java.io.Serializable;

/**
 * Represents a Course entity.
 */
public class Course implements Serializable {

    private static final long serialVersionUID = 1L;
    private int courseID;
    private String courseName;
    private String courseCode;
    private String description;

    /**
     * Constructs a Course object with the specified attributes.
     * @param courseID The ID of the course.
     * @param courseName The name of the course.
     * @param courseCode The code of the course.
     * @param description The description of the course.
     */
    public Course(int courseID, String courseName, String courseCode, String description) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.description = description;
    }

    /**
     * Returns a string representation of the Course object.
     * @return A string representation of the Course object.
     */
    @Override
    public String toString() {
        return "Course [courseID=" + courseID + ", courseName=" + courseName + ", courseCode=" + courseCode
                + ", description=" + description + "]";
    }

    /**
     * Retrieves the ID of the course.
     * @return The ID of the course.
     */
    public int getCourseID() {
        return courseID;
    }

    /**
     * Sets the ID of the course.
     * @param courseID The ID of the course.
     */
    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    /**
     * Retrieves the name of the course.
     * @return The name of the course.
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * Sets the name of the course.
     * @param courseName The name of the course.
     */
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    /**
     * Retrieves the code of the course.
     * @return The code of the course.
     */
    public String getCourseCode() {
        return courseCode;
    }

    /**
     * Sets the code of the course.
     * @param courseCode The code of the course.
     */
    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    /**
     * Retrieves the description of the course.
     * @return The description of the course.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description of the course.
     * @param description The description of the course.
     */
    public void setDescription(String description) {
        this.description = description;
    }
}

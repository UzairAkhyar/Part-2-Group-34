package modelView;


import java.io.Serializable;

public class Student implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int studentID;
    private int userID;
    private String registrationDate;
    
	public Student(int studentID, int userID, String registrationDate) {
		super();
		this.studentID = studentID;
		this.userID = userID;
		this.registrationDate = registrationDate;
	}	

	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", userID=" + userID + ", registrationDate=" + registrationDate
				+ "]";
	}

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}
    
}

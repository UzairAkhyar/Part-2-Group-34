package modelView;


import java.io.Serializable;

public class Lecturer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int lecturerID;
    private int userID;
    private String hireDate;
    
	public Lecturer(int lecturerID, int userID, String hireDate) {
		super();
		this.lecturerID = lecturerID;
		this.userID = userID;
		this.hireDate = hireDate;
	}
	
	@Override
	public String toString() {
		return "Lecturer [lecturerID=" + lecturerID + ", userID=" + userID + ", hireDate=" + hireDate + "]";
	}

	public int getLecturerID() {
		return lecturerID;
	}

	public void setLecturerID(int lecturerID) {
		this.lecturerID = lecturerID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getHireDate() {
		return hireDate;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
 
}

package modelView;


import java.io.Serializable;

public class CourseAssignment implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int assignmentID;
    private int courseID;
    private int lecturerID;
    private String trimester;
    private int year;
    
	public CourseAssignment(int assignmentID, int courseID, int lecturerID, String trimester, int year) {
		super();
		this.assignmentID = assignmentID;
		this.courseID = courseID;
		this.lecturerID = lecturerID;
		this.trimester = trimester;
		this.year = year;
	}
	
	@Override
	public String toString() {
		return "CourseAssignment [assignmentID=" + assignmentID + ", courseID=" + courseID + ", lecturerID="
				+ lecturerID + ", trimester=" + trimester + ", year=" + year + "]";
	}

	public int getAssignmentID() {
		return assignmentID;
	}

	public void setAssignmentID(int assignmentID) {
		this.assignmentID = assignmentID;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

	public int getLecturerID() {
		return lecturerID;
	}

	public void setLecturerID(int lecturerID) {
		this.lecturerID = lecturerID;
	}

	public String getTrimester() {
		return trimester;
	}

	public void setTrimester(String trimester) {
		this.trimester = trimester;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
      
}

package databaseManager;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import modelView.User;

public class UserDatabaseController extends FileServer {
    private ArrayList<User> userList;

    public UserDatabaseController(String fileName) {
        super("UserDB.txt");
        this.userList = new ArrayList<>();
        loadDataFromFile();
    }

    public boolean insertUser(User data) {
        if (isUserIdExists(data.getUserID())) {
            System.out.println("User ID already exists!");
            return false;
        }
        
        if(isUserGmailExists(data.getEmail())) {
        	System.out.println("User gmail already exists!");
            return false;
        }
        
        userList.add(data);
        try {
            saveDataToFile();
            return true;
        } catch (IOException e) {
            System.out.println("Failed to save data to file: " + e.getMessage());
            return false;
        }
    }

    public boolean isUserIdExists(int userID) {
        for (User user : userList) {
            if (user.getUserID() == userID) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isUserGmailExists(String userGmail) {
        for (User user : userList) {
            if (user.getEmail().equals(userGmail)) {
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private void loadDataFromFile() {
        try {
            if (!DB.exists()) {
                saveDataToFile();
            } else {
                fis = new FileInputStream(DB);
                ois = new ObjectInputStream(fis);
                userList = (ArrayList<User>) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Failed to load data from file: " + e.getMessage());
        } finally {
            try {
                if (fis != null)
                    fis.close();
                if (ois != null)
                    ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveDataToFile() throws IOException {
        if (DB.exists()) {
            try {
                fos = new FileOutputStream(DB);
                oos = new ObjectOutputStream(fos);
                oos.writeObject(userList);
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            } finally {
                try {
                    if (fos != null)
                        fos.close();
                    if (oos != null)
                        oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("File does not exist: " + DB.getAbsolutePath());
        }
    }

    public List<User> getAllUsers() {
        loadDataFromFile();
        return new ArrayList<>(userList);
    }

    public User isUser(String gmail, String password) {
        for (User user : userList) {
            if (user.getEmail().equals(gmail) && user.getPassword().equals(password)) {
                return user; 
            }
        }
        return null; 
    }
    
    public List<Integer> getAllUserIDs() {
        List<Integer> userIds = new ArrayList<>();
        for (User user : userList) {
            userIds.add(user.getUserID());
        }
        return userIds;
    }
    
    public String getEmailByUserID(int userID) {
        for (User user : userList) {
            if (user.getUserID() == userID) {
                return user.getEmail();
            }
        }
        return null;
    }
    
    public int getUserIdByGmail(String gmail) {
        for (User user : userList) {
            if (user.getEmail().equals(gmail)) {
                return user.getUserID();
            }
        }
        return -1; 
    }

    public void printAllUsers() {
        System.out.println("User Data:");

        for (User user : userList) {
            System.out.println("User ID: " + user.getUserID());
            System.out.println("Username: " + user.getUsername());
            System.out.println("Password: " + user.getPassword());
            System.out.println("User Type: " + user.getUserType());
            System.out.println("First Name: " + user.getFirstName());
            System.out.println("Last Name: " + user.getLastName());
            System.out.println("Email: " + user.getEmail());
            System.out.println("-----");
        }
    }
    
    public User getUserByUserID(int userID) {
        for (User user : userList) {
            if (user.getUserID() == userID) {
                return user;
            }
        }
        return null;
    }

    
}

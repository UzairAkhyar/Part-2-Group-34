package databaseManager;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import modelView.Student;

public class StudentDatabaseController extends FileServer {
	//private StudentCourseRegistrationDatabaseController SCR_DB = new StudentCourseRegistrationDatabaseController(null);
    //private UserDatabaseController userDatabaseController = new UserDatabaseController(null);
	private ArrayList<Student> studentList;

    public StudentDatabaseController(String fileName) {
        super("StudentDB.txt");
        this.studentList = new ArrayList<>();
        loadDataFromFile();
    }

    public boolean insertStudent(Student data) {
    	
    	if (isStudentIdExists(data.getStudentID())) {
            System.out.println("student id already exists!");
            return false;
        }
    	
    	
//    	if(!userDatabaseController.isUserIdExists(data.getUserID())) {
//    		System.out.println("User id not valid!");
//            return false;
//    	}
    	
    	studentList.add(data);
        try {
            saveDataToFile(); 
            return true;
        } catch (IOException e) {
            System.out.println("failed to save data to file!");
            return true;
        }
    }

    public List<Integer> getAllStudentIds() {
        List<Integer> studentIds = new ArrayList<>();
        for (Student student : studentList) {
            studentIds.add(student.getStudentID());
        }
        return studentIds;
    }

    public boolean isStudentIdExists(int studentID) {
        for (Student student : studentList) {
            if (student.getStudentID() == studentID) {
                return true;
            }
        }
        return false;
    }
    
	@SuppressWarnings("unchecked")
    private void loadDataFromFile() {
        try {
            if (!DB.exists()) {
                saveDataToFile();
            } else {
                fis = new FileInputStream(DB);
                ois = new ObjectInputStream(fis);
                studentList = (ArrayList<Student>) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Failed to load data from file: " + e.getMessage());
        } finally {
            try {
                if (fis != null)
                    fis.close();
                if (ois != null)
                    ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveDataToFile() throws IOException {
        if (DB.exists()) {
            try {
                fos = new FileOutputStream(DB);
                oos = new ObjectOutputStream(fos);
                oos.writeObject(studentList);
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            } finally {
            	try {
                    if (fos != null)
                        fos.close();
                    if (oos != null)
                        oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("file dose not exist:" + DB.getAbsolutePath());
        }
    }

    public List<Student> getAllStudent() {
    	loadDataFromFile();
    	return new ArrayList<>(studentList);
    }

    public boolean checkUserID(int userID) {
    	for(Student student : studentList){
    		if(student.getUserID() == userID) {
    			return true;
    		}
    	}
    	return false;
    }
    

    public Student getByStudentId(int studentID) {
        for (Student student : studentList) {
            if (student.getStudentID() == studentID) {
                return student;
            }
        }
        return null;
    }
    
    public int getStudentIdByUserId(int userID) {
        for (Student student : studentList) {
            if (student.getUserID() == userID) {
                return student.getStudentID();
            }
        }
        return -1; 
    }
    
}

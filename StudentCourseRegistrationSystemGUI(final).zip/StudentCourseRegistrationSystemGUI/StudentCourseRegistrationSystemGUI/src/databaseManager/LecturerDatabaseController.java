package databaseManager;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import modelView.Lecturer;

public class LecturerDatabaseController extends FileServer {
	private UserDatabaseController userDatabaseController = new UserDatabaseController(null);
    private ArrayList<Lecturer> lecturerList;

    public LecturerDatabaseController(String fileName) {
        super("LecturerDB.txt");
        this.lecturerList = new ArrayList<>();
        loadDataFromFile();
    }

    public boolean insertLecturer(Lecturer data) {
    	
        if (isLecturerIdExists(data.getLecturerID())) {
            System.out.println("Lecturer ID already exists!");
            return false;
        }
        
//        if(!userDatabaseController.isUserIdExists(data.getUserID())) {
//    		System.out.println("User id not valid!");
//            return false;
//    	}
        
        lecturerList.add(data);
        try {
            saveDataToFile();
            return true;
        } catch (IOException e) {
            System.out.println("Failed to save data to file!");
            return false;
        }
    }

    public List<Integer> getAllLecturerIds() {
        List<Integer> lecturerIds = new ArrayList<>();
        for (Lecturer lecturer : lecturerList) {
            lecturerIds.add(lecturer.getLecturerID());
        }
        return lecturerIds;
    }

    public boolean isLecturerIdExists(int lecturerID) {
        for (Lecturer lecturer : lecturerList) {
            if (lecturer.getLecturerID() == lecturerID) {
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private void loadDataFromFile() {
        try {
            if (!DB.exists()) {
                saveDataToFile();
            } else {
                fis = new FileInputStream(DB);
                ois = new ObjectInputStream(fis);
                lecturerList = (ArrayList<Lecturer>) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Failed to load data from file: " + e.getMessage());
        } finally {
            try {
                if (fis != null)
                    fis.close();
                if (ois != null)
                    ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveDataToFile() throws IOException {
        if (DB.exists()) {
            try {
                fos = new FileOutputStream(DB);
                oos = new ObjectOutputStream(fos);
                oos.writeObject(lecturerList);
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            } finally {
                try {
                    if (fos != null)
                        fos.close();
                    if (oos != null)
                        oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("File does not exist: " + DB.getAbsolutePath());
        }
    }

    public List<Lecturer> getAllLecturers() {
        loadDataFromFile();
        return new ArrayList<>(lecturerList);
    }

    public boolean checkUserID(int userId) {
    	for (Lecturer lecturer : lecturerList) {
            if(lecturer.getUserID() == userId) {
            	return true;
            }
        }
    	return false;
    }  

    public List<String> getAllLecturersFormatted() {
        List<String> lecturerInfoList = new ArrayList<>();
        for (Lecturer lecturer : lecturerList) {
            int lecturerID = lecturer.getLecturerID();
            String email = userDatabaseController.getEmailByUserID(lecturer.getUserID());
            String lecturerInfo = lecturerID + " - " + email;
            lecturerInfoList.add(lecturerInfo);
        }
        return lecturerInfoList;
    }
    
    public int getLecturerIdByUserId(int userID) {
        for (Lecturer lecturer : lecturerList) {
            if (lecturer.getUserID() == userID) {
                return lecturer.getLecturerID();
            }
        }
        return -1; 
    }

}

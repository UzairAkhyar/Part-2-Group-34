package databaseManager;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileServer {
	protected File DB = null;
	protected FileOutputStream fos = null;
	protected FileInputStream fis = null;
	protected ObjectOutputStream oos = null;
	protected ObjectInputStream ois = null;

	public FileServer(String fileName) {
		this.DB = new File(fileName);

		if (DB.exists()) {
			//System.out.println("file already exist!");
		} else {
			try {
				DB.createNewFile();
			} catch (IOException e) {
				System.out.println("failed to create new file!");
			}
		}
	}
}

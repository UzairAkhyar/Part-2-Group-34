package databaseManager;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import modelView.StudentCourseRegistration;

public class StudentCourseRegistrationDatabaseController extends FileServer {
    private ArrayList<StudentCourseRegistration> StudentCourseRegistrationList;
    private StudentDatabaseController studentDatabaseController = new StudentDatabaseController(null); 
    private CourseDatabaseController courseDatabaseController = new CourseDatabaseController(null);

    public StudentCourseRegistrationDatabaseController(String fileName) {
        super("StudentCourseRegDB.txt");
        this.StudentCourseRegistrationList = new ArrayList<>();
        loadDataFromFile();
    }

    public boolean insertCourseRegistration(StudentCourseRegistration data) {
    	
    	//check primary key
        if (isCourseRegistrationIdExists(data.getRegistrationID())) {
            System.out.println("Course Assignment ID already exists!");
            return false;
        }
        
        if(!studentDatabaseController.isStudentIdExists(data.getStudentID())) {
        	System.out.println("Stident id not valid!");
            return false;
        }
          
        if(!courseDatabaseController.isCourseIdExists(data.getCourseID())) {
        	System.out.println("Course id not valid!");
            return false;
        }

        StudentCourseRegistrationList.add(data);
        try {
            saveDataToFile();
            return true;
        } catch (IOException e) {
            System.out.println("Failed to save data to file: " + e.getMessage());
            return false;
        }
    }
    
    public boolean isCourseRegistrationIdExists(int registyrationID) {
        for (StudentCourseRegistration registrationCourse : StudentCourseRegistrationList) {
            if (registrationCourse.getRegistrationID() == registyrationID) {
                return true;
            }
        }
        return false;
    }
  
    @SuppressWarnings("unchecked")
    private void loadDataFromFile() {
        try {
            if (!DB.exists()) {
                saveDataToFile();
            } else {
                fis = new FileInputStream(DB);
                ois = new ObjectInputStream(fis);
                StudentCourseRegistrationList = (ArrayList<StudentCourseRegistration>) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Failed to load data from file: " + e.getMessage());
        } finally {
            try {
                if (fis != null)
                    fis.close();
                if (ois != null)
                    ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveDataToFile() throws IOException {
        if (DB.exists()) {
            try {
                fos = new FileOutputStream(DB);
                oos = new ObjectOutputStream(fos);
                oos.writeObject(StudentCourseRegistrationList);
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            } finally {
                try {
                    if (fos != null)
                        fos.close();
                    if (oos != null)
                        oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("File does not exist: " + DB.getAbsolutePath());
        }
    }

    public List<StudentCourseRegistration> getAllRegistrCourse() {
        loadDataFromFile();
        return new ArrayList<>(StudentCourseRegistrationList);
    }

	public List<StudentCourseRegistration> getRegisteredStudentsByCourseId(int courseId) {
	    List<StudentCourseRegistration> registeredStudents = new ArrayList<>();
	    for (StudentCourseRegistration registration : StudentCourseRegistrationList) {
	        if (registration.getCourseID() == courseId) {
	            registeredStudents.add(registration);
	        }
	    }
	    return registeredStudents;
	}

	public List<StudentCourseRegistration> getAllCourseByStudentID(int student_id) {
	    List<StudentCourseRegistration> studentCourses = new ArrayList<>();
	    for (StudentCourseRegistration registration : StudentCourseRegistrationList) {
	        if (registration.getStudentID() == student_id) {
	            studentCourses.add(registration);
	        }
	    }
	    return studentCourses;
	}


}

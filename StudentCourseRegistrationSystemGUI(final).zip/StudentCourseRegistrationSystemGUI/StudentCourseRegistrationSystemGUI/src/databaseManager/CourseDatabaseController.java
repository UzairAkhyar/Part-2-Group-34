package databaseManager;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import modelView.Course;

public class CourseDatabaseController extends FileServer {
    private ArrayList<Course> courseList;

    public CourseDatabaseController(String fileName) {
        super("CourseDB.txt");
        this.courseList = new ArrayList<>();
        loadDataFromFile();
    }

    public boolean insertCourse(Course data) {
        if (isCourseIdExists(data.getCourseID())) {
            System.out.println("Course ID already exists!");
            return false;
        }

        courseList.add(data);
        try {
            saveDataToFile();
            return true;
        } catch (IOException e) {
            System.out.println("Failed to save data to file: " + e.getMessage());
            return false;
        }
    }

    public boolean isCourseIdExists(int courseID) {
        for (Course course : courseList) {
            if (course.getCourseID() == courseID) {
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private void loadDataFromFile() {
        try {
            if (!DB.exists()) {
                saveDataToFile();
            } else {
                fis = new FileInputStream(DB);
                ois = new ObjectInputStream(fis);
                courseList = (ArrayList<Course>) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Failed to load data from file: " + e.getMessage());
        } finally {
            try {
                if (fis != null)
                    fis.close();
                if (ois != null)
                    ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveDataToFile() throws IOException {
        if (DB.exists()) {
            try {
                fos = new FileOutputStream(DB);
                oos = new ObjectOutputStream(fos);
                oos.writeObject(courseList);
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            } finally {
                try {
                    if (fos != null)
                        fos.close();
                    if (oos != null)
                        oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("File does not exist: " + DB.getAbsolutePath());
        }
    }

    public List<Course> getAllCourses() {
        loadDataFromFile();
        return new ArrayList<>(courseList);
    }
    
    public List<Course> getAvailableCourses() {
        CourseDatabaseController courseDatabaseController = new CourseDatabaseController(null);
        return courseDatabaseController.getAllCourses();
    }

    public List<String> getAllCourseCodes() {
        List<String> courseCodes = new ArrayList<>();
        for (Course course : courseList) {
            courseCodes.add(course.getCourseCode());
        }
        return courseCodes;
    }

    public int getCourseIdByCourseCode(String courseCode) {
        for (Course course : courseList) {
            if (course.getCourseCode().equalsIgnoreCase(courseCode)) {
                return course.getCourseID();
            }
        }
        return -1;
    }

    
}

package databaseManager;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import modelView.CourseAssignment;

public class CourseAssignDatabaseController extends FileServer {
	private CourseDatabaseController course_DC = new CourseDatabaseController(null);
	private LecturerDatabaseController lecturer_DC = new LecturerDatabaseController(null);
    private ArrayList<CourseAssignment> courseAssignmentList;

    public CourseAssignDatabaseController(String fileName) {
        super("CourseAssignmentDB.txt");
        this.courseAssignmentList = new ArrayList<>();
        loadDataFromFile();
    }

    public boolean insertCourseAssignment(CourseAssignment data) {
    	
    	//check primary key
        if (isCourseAssignmentIdExists(data.getAssignmentID())) {
            System.out.println("Course Assignment ID already exists!");
            return false;
        }
        
        //check valid course id
        if (!course_DC.isCourseIdExists(data.getCourseID())) {
        	System.out.println("Invalid Course Id!");
        	return false;
        }
   
        //check valid lecturer id
        if(!lecturer_DC.isLecturerIdExists(data.getLecturerID())) {
        	System.out.println("Invalid Lecturer Id!");
        	return false;
        }
            

        courseAssignmentList.add(data);
        try {
            saveDataToFile();
            return true;
        } catch (IOException e) {
            System.out.println("Failed to save data to file: " + e.getMessage());
            return false;
        }
    }
    
    //we have to check courseID, LecturerID 

    public boolean isCourseAssignmentIdExists(int courseAssignmentID) {
        for (CourseAssignment courseAssignment : courseAssignmentList) {
            if (courseAssignment.getAssignmentID() == courseAssignmentID) {
                return true;
            }
        }
        return false;
    }

  
    @SuppressWarnings("unchecked")
    private void loadDataFromFile() {
        try {
            if (!DB.exists()) {
                saveDataToFile();
            } else {
                fis = new FileInputStream(DB);
                ois = new ObjectInputStream(fis);
                courseAssignmentList = (ArrayList<CourseAssignment>) ois.readObject();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Failed to load data from file: " + e.getMessage());
        } finally {
            try {
                if (fis != null)
                    fis.close();
                if (ois != null)
                    ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveDataToFile() throws IOException {
        if (DB.exists()) {
            try {
                fos = new FileOutputStream(DB);
                oos = new ObjectOutputStream(fos);
                oos.writeObject(courseAssignmentList);
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            } finally {
                try {
                    if (fos != null)
                        fos.close();
                    if (oos != null)
                        oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("File does not exist: " + DB.getAbsolutePath());
        }
    }

    public List<CourseAssignment> getAllCourseAssignments() {
        loadDataFromFile();
        return new ArrayList<>(courseAssignmentList);
    }

    public List<CourseAssignment> getAllCourseAssignmentsByLecturerId(int lecturerID) {
        List<CourseAssignment> lecturerAssignments = new ArrayList<>();
        for (CourseAssignment assignment : courseAssignmentList) {
            if (assignment.getLecturerID() == lecturerID) {
                lecturerAssignments.add(assignment);
            }
        }
        return lecturerAssignments;
    }

}

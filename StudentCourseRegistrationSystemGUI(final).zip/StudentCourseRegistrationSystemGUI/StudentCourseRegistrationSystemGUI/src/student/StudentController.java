package student;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import util.Helper;

/**
 * Controller class for the Student view.
 * Handles interactions and logic related to the Student view.
 */
public class StudentController implements Initializable {

    @FXML
    private StackPane admin_content_container_stack_pan;

    @FXML
    private ImageView admin_left_head_img;

    @FXML
    private AnchorPane admin_left_menu_container;

    @FXML
    private ImageView admin_left_menu_icon_apointment;

    @FXML
    private ImageView admin_left_menu_icon_logout;

    @FXML
    private AnchorPane admin_left_menu_items_container3;

    @FXML
    private AnchorPane admin_left_menu_items_container31;

    @FXML
    private AnchorPane admin_main_container;

    @FXML
    private ImageView image;
    
    private Helper helper = new Helper();
    
    private ActionEvent event = new ActionEvent();

    /**
     * Handles the action when the course registration button is clicked.
     * @param event The ActionEvent triggered by clicking the course registration button.
     * @throws IOException If an error occurs while loading the course registration view.
     */
    @FXML
    void courseRegistrationBTN(ActionEvent event) throws IOException {
    	helper.loadContainer(admin_content_container_stack_pan, "/student/courseRegistration/CourseRegistration.fxml");
    }

    /**
     * Handles the action when the log out button is clicked.
     * @param event The ActionEvent triggered by clicking the log out button.
     * @throws IOException If an error occurs while redirecting to the login page.
     */
    @FXML
    void logOut_action_btn(ActionEvent event) throws IOException {
    	helper.logOut_action_btn(event, admin_content_container_stack_pan, "/authentication/Login.fxml");
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// Set student logo image
		Image admin_logo_icon = new Image(getClass().getResourceAsStream("/images/student-logo.png"));
		admin_left_head_img.setImage(admin_logo_icon);
		
		try {
			courseRegistrationBTN(event);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}

package student.courseRegistration;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

import authentication.LoginController;
import databaseManager.CourseDatabaseController;
import databaseManager.StudentCourseRegistrationDatabaseController;
import databaseManager.StudentDatabaseController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import modelView.StudentCourseRegistration;
import util.Helper;

/**
 * Controller class for the course registration view in the student dashboard.
 * Handles course registration actions and manages data display in the table.
 */
public class CourseRegistrationController implements Initializable {

    @FXML
    private TableColumn<StudentCourseRegistration, Integer> courseID_col;

    @FXML
    private ComboBox<String> courseID_tf;

    @FXML
    private TextField courseRegId_tf;

    @FXML
    private TableView<StudentCourseRegistration> courseReg_table;

    @FXML
    private TableColumn<StudentCourseRegistration, Integer> regID_col;

    @FXML
    private TableColumn<StudentCourseRegistration, Integer> stdID_col;

    @FXML
    private TextField studentID_tf;

    @FXML
    private TableColumn<StudentCourseRegistration, String> triemster_col;

    @FXML
    private TextField trimester_tf;

    @FXML
    private TableColumn<StudentCourseRegistration, Integer> year_col;

    @FXML
    private TextField year_tf;
    
    private LoginController loginController = new LoginController();
    
    private CourseDatabaseController courseDbController = new CourseDatabaseController(null);
    private static StudentDatabaseController stdRegDbController = new StudentDatabaseController(null);
    //private CourseAssignDatabaseController courseAssignDbController = new CourseAssignDatabaseController(null);
    private StudentCourseRegistrationDatabaseController StdCourseRegDabController = new StudentCourseRegistrationDatabaseController(null);
    private Helper helper = new Helper();

    /**
     * Handles the action when the add button is clicked to register for a course.
     * @param event The ActionEvent triggered by clicking the add button.
     */
    @FXML
    void addBTN(ActionEvent event) {
        try {
            int registrationID = Integer.parseInt(courseRegId_tf.getText());
            int studentID = Integer.parseInt(studentID_tf.getText());
            int courseID = courseDbController.getCourseIdByCourseCode(courseID_tf.getValue());
            String trimester = trimester_tf.getText();
            int year = Integer.parseInt(year_tf.getText());
            String currentDateStr = helper.getCurrentDate();

            if (registrationID == 0 || studentID == 0 || courseID == 0 || trimester.isEmpty() || year == 0) {
                helper.showAlert("Empty Input", "Input fields cannot be empty or zero.");
                return;
            }

            LocalDate currentDate = LocalDate.parse(currentDateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            
            StudentCourseRegistration studentCourseRegistration = new StudentCourseRegistration(registrationID, studentID, courseID, trimester, year, currentDate);
            boolean isInsert = StdCourseRegDabController.insertCourseRegistration(studentCourseRegistration);

            if (isInsert) {
                helper.showAlert("Success", "Student course registration added successfully.");
                clearBTN(event);
                loadTableData();
            } else {
                helper.showAlert("Error", "Failed to add student course registration.");
            }

        } catch (NumberFormatException e) {
            helper.showAlert("Invalid Input", "Please enter valid numeric values for ID and Year.");
        }
    }

    /**
     * Handles the action when the clear button is clicked to clear input fields.
     * @param event The ActionEvent triggered by clicking the clear button.
     */
    @FXML
    void clearBTN(ActionEvent event) {
        courseRegId_tf.clear();
        studentID_tf.clear();
        courseID_tf.getSelectionModel().clearSelection();
        trimester_tf.clear();
        year_tf.clear();
    }

    /**
     * Loads data into the course registration table.
     * Retrieves all course registrations for the current student and populates the table.
     */
    private void loadTableData() {
        List<StudentCourseRegistration> allRegistrations = StdCourseRegDabController.getAllCourseByStudentID(stdRegDbController.getStudentIdByUserId(loginController.getUserId()));

        if (allRegistrations != null) {
            ObservableList<StudentCourseRegistration> registrationData = FXCollections.observableArrayList(allRegistrations);

            regID_col.setCellValueFactory(new PropertyValueFactory<>("registrationID"));
            stdID_col.setCellValueFactory(new PropertyValueFactory<>("studentID"));
            courseID_col.setCellValueFactory(new PropertyValueFactory<>("courseID"));
            triemster_col.setCellValueFactory(new PropertyValueFactory<>("trimester"));
            year_col.setCellValueFactory(new PropertyValueFactory<>("year"));

            courseReg_table.setItems(registrationData);
        }
    }

    /**
     * Initializes the controller.
     * Loads course codes into the course ID combo box, sets initial values for input fields,
     * and loads data into the course registration table.
     */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		List<String> allCorseCode = courseDbController.getAllCourseCodes();
		courseID_tf.getItems().addAll(allCorseCode);
		
		courseRegId_tf.setText(helper.generateRandomNumber(8)+"");
		
		loadTableData();
		
		// Set student ID automatically
		studentID_tf.setText(stdRegDbController.getStudentIdByUserId(loginController.getUserId())+"");
	}

	/**
	 * Main method for testing purposes.
	 * Checks if a given student ID exists in the database.
	 * @param args Command line arguments.
	 */
	public static void main(String [] args) {
		// Test student ID existence
		boolean isTrue = stdRegDbController.isStudentIdExists(76258022);

		System.out.println("True / false : "+isTrue);
	}
	
}

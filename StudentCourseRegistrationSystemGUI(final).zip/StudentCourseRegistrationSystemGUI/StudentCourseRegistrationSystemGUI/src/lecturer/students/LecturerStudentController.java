package lecturer.students;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import modelView.Student;
import modelView.StudentCourseRegistration;

import authentication.LoginController;
import modelView.CourseAssignment;
import modelView.ShowStudentLecturerPanel;
import databaseManager.CourseAssignDatabaseController;
import databaseManager.LecturerDatabaseController;
import databaseManager.StudentCourseRegistrationDatabaseController;
import databaseManager.StudentDatabaseController;
import databaseManager.UserDatabaseController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import modelView.User;

public class LecturerStudentController implements Initializable {

    @FXML
    private ComboBox<Integer> course_tf;

    @FXML
    private TableColumn<ShowStudentLecturerPanel, String> registrationDate_col;

    @FXML
    private TableColumn<ShowStudentLecturerPanel, String> stdGmail_col;

    @FXML
    private TableColumn<ShowStudentLecturerPanel, String> stdName_col;

    @FXML
    private TableColumn<ShowStudentLecturerPanel, Integer> studentId_col;

    @FXML
    private TableView<ShowStudentLecturerPanel> student_table;
    
    private UserDatabaseController userDbController = new UserDatabaseController(null);
    private StudentDatabaseController studentDatabaseController = new StudentDatabaseController(null);
    private StudentCourseRegistrationDatabaseController courseRegDbController = new StudentCourseRegistrationDatabaseController(null);
    private CourseAssignDatabaseController courseAssignDatabaseController = new CourseAssignDatabaseController(null);
    private LecturerDatabaseController LecDbController = new LecturerDatabaseController(null);
    private LoginController loginController = new LoginController();
 
    private List<ShowStudentLecturerPanel> showStudentList = new ArrayList<>(); 
    
    @FXML
    void filterBTN(ActionEvent event) {

    }
    
    private void print() {
    	for(ShowStudentLecturerPanel data : showStudentList) {
    		System.out.println("Student Data : "+data.getStudent_ID());
    		System.out.println("Student name : "+data.getStudent_full_name());
    		System.out.println("Student gmail : "+data.getStudent_gmail());
    		System.out.println("Course registration date : "+data.getCourse_reg_date());
    	}
    }
    
//    private void GetTableData() {
//    	int Student_ID = 0;
//    	String Student_gmail = "";
//    	String Student_full_name = "";
//    	String Course_reg_date = "";
//    	
//    	 List<CourseAssignment> assignedCourses = courseAssignDatabaseController.getAllCourseAssignmentsByLecturerId(LecDbController.getLecturerIdByUserId(loginController.getUserId()));
//
//         if (assignedCourses.isEmpty()) {
//             System.out.println("No courses assigned to the lecturer.");
//         } else {
//        	 
//        	 for (CourseAssignment courseAssignment : assignedCourses) {
//        		 
//        		 ShowStudentLecturerPanel showStudentLecturerPanel = new ShowStudentLecturerPanel();
//        		 
//                 int courseID = courseAssignment.getCourseID();
//
//                 List<StudentCourseRegistration> registeredStudents = courseRegDbController.getRegisteredStudentsByCourseId(courseID);
//
//                 System.out.println("\n:::::::::::::::::::::::::Students of Course " + courseID + ":::::::::::::::::::::::::::");
//                 if (registeredStudents.isEmpty()) {
//                     System.out.println("No students registered for this course.");
//                 } else {
//                	 
//                     for (StudentCourseRegistration registration : registeredStudents) {                  	 
//                    	 //get some info
//                    	 Course_reg_date = ""+registration.getRegistrationDate();
//                    	 showStudentLecturerPanel.setCourse_reg_date(Course_reg_date);
//                    	 
//                         Student student = studentDatabaseController.getByStudentId(registration.getStudentID());
//                         
//                         if(student != null) {
//                        	 
//                        	//get some info
//                        	Student_ID = student.getStudentID();
//                        	showStudentLecturerPanel.setStudent_ID(Student_ID);
//                        	
//                        	User user_list = userDbController.getUserByUserID(student.getUserID());
//                        	
//                         	if(user_list != null) {
//                         		//get some info
//                         		Student_gmail = user_list.getEmail();
//                         		showStudentLecturerPanel.setStudent_gmail(Student_gmail);
//                            	Student_full_name = user_list.getFirstName()+" "+user_list.getLastName();
//                            	showStudentLecturerPanel.setStudent_full_name(Student_full_name);
//                         	}
//                         	
//                         }
//                     }
//                 }
//                 
//                 showStudentList.add(showStudentLecturerPanel);     
//             }
//        	 
//        	 
//         }
//    	
//    	
//    }
    
    private void GetTableData() {
        int lecturerID = LecDbController.getLecturerIdByUserId(loginController.getUserId());
        List<CourseAssignment> assignedCourses = courseAssignDatabaseController.getAllCourseAssignmentsByLecturerId(lecturerID);

        for (CourseAssignment courseAssignment : assignedCourses) {
            int courseID = courseAssignment.getCourseID();
            List<StudentCourseRegistration> registeredStudents = courseRegDbController.getRegisteredStudentsByCourseId(courseID);

            if (!registeredStudents.isEmpty()) {
                for (StudentCourseRegistration registration : registeredStudents) {
                    ShowStudentLecturerPanel showStudentLecturerPanel = new ShowStudentLecturerPanel();

                    int studentID = registration.getStudentID();
                    Student student = studentDatabaseController.getByStudentId(studentID);

                    if (student != null) {
                        showStudentLecturerPanel.setStudent_ID(studentID);
                        User user = userDbController.getUserByUserID(student.getUserID());

                        if (user != null) {
                            showStudentLecturerPanel.setStudent_gmail(user.getEmail());
                            showStudentLecturerPanel.setStudent_full_name(user.getFirstName() + " " + user.getLastName());
                        }
                    }

                    showStudentLecturerPanel.setCourse_reg_date("" + registration.getRegistrationDate());

                    showStudentList.add(showStudentLecturerPanel);
                }
            }
        }
    }


    
    @FXML
    private void loadTableData() {
        ObservableList<ShowStudentLecturerPanel> studentData = FXCollections.observableArrayList(showStudentList);

        studentId_col.setCellValueFactory(new PropertyValueFactory<>("student_ID"));
        registrationDate_col.setCellValueFactory(new PropertyValueFactory<>("course_reg_date"));
        stdGmail_col.setCellValueFactory(new PropertyValueFactory<>("student_gmail"));
        stdName_col.setCellValueFactory(new PropertyValueFactory<>("student_full_name"));

        student_table.setItems(studentData);
    }

    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		GetTableData();
		print();
		loadTableData();
	}

}

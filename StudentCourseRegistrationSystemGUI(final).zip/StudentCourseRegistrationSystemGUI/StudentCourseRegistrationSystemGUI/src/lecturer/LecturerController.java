package lecturer;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import util.Helper;

/**
 * Controller class for the Lecturer view.
 * Handles interactions and logic related to the Lecturer view.
 */
public class LecturerController implements Initializable {

    @FXML
    private StackPane admin_content_container_stack_pan;

    @FXML
    private ImageView admin_left_head_img;

    @FXML
    private AnchorPane admin_left_menu_container;

    @FXML
    private ImageView admin_left_menu_icon_admin;

    @FXML
    private ImageView admin_left_menu_icon_logout;

    @FXML
    private AnchorPane admin_left_menu_items_container;

    @FXML
    private AnchorPane admin_left_menu_items_container31;

    @FXML
    private AnchorPane admin_main_container;

    @FXML
    private ImageView image;
    
    private Helper helper = new Helper();
    
    private ActionEvent event = new ActionEvent();

    /**
     * Handles the action when the user clicks on the log out button.
     * @param event The ActionEvent triggered by clicking the log out button.
     * @throws IOException If an error occurs while redirecting to the login page.
     */
    @FXML
    void logOut_action_btn(ActionEvent event) throws IOException {
    	helper.logOut_action_btn(event, admin_content_container_stack_pan, "/authentication/Login.fxml");
    }

    /**
     * Handles the action when the user clicks on the button to see course students.
     * @param event The ActionEvent triggered by clicking the button.
     * @throws IOException If an error occurs while loading the course students view.
     */
    @FXML
    void seeCourseStudentBTN(ActionEvent event) throws IOException {
    	helper.loadContainer(admin_content_container_stack_pan, "/lecturer/students/LecturerStudent.fxml");
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		try {
			seeCourseStudentBTN(event);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
